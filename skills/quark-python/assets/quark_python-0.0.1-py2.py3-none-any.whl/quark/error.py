from __future__ import absolute_import


class Error(Exception):
    pass


class Warning(Exception):
    pass


# DB API (PEP 249) exceptions

class InterfaceError(Error):
    pass


class DatabaseError(Error):
    pass


class InternalError(DatabaseError):
    pass


class OperationalError(DatabaseError):
    pass


class ProgrammingError(DatabaseError):
    pass


class IntegrityError(DatabaseError):
    pass


class DataError(DatabaseError):
    pass


class NotSupportedError(DatabaseError):
    pass


# RPC errors

class RPCError(Error):
    pass


class HiveServer2Error(RPCError):
    pass

class BeeswaxError(RPCError):
    pass


class QueryStateError(BeeswaxError):
    pass


class DisconnectedError(BeeswaxError):
    pass
