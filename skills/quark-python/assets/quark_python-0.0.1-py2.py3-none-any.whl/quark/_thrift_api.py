# pylint: disable=wrong-import-position

from __future__ import absolute_import

import getpass

from quark.util import get_logger_and_init_null
log = get_logger_and_init_null(__name__)

# pylint: disable=import-error,unused-import
# import Apache Thrift code
from thrift.transport.TSocket import TSocket
from thrift.transport.TTransport import (
    TBufferedTransport, TTransportException, TTransportBase)


from quark._thrift_gen.TCLIService import TCLIService
ThriftClient = TCLIService.Client

def get_socket(host, port, use_ssl, ca_cert):
    log.debug('get_socket: host=%s port=%s use_ssl=%s ca_cert=%s',
              host, port, use_ssl, ca_cert)
    if use_ssl:
        from thrift.transport.TSSLSocket import TSSLSocket

        class QuarkTSSLSocket(TSSLSocket):
            # THRIFT-5595: override TSocket.isOpen because it's broken for TSSLSocket
            def isOpen(self):
                return self.handle is not None

        if ca_cert is None:
            return QuarkTSSLSocket(host, port, validate=False)
        else:
            return QuarkTSSLSocket(host, port, validate=True, ca_certs=ca_cert)
    else:
        return TSocket(host, port)


def get_transport(socket, host, kerberos_service_name, auth_mechanism='NOSASL',
                  user=None, password=None):
    log.debug('get_transport: socket=%s host=%s kerberos_service_name=%s '
              'auth_mechanism=%s user=%s password=fuggetaboutit', socket, host,
              kerberos_service_name, auth_mechanism, user)

    if auth_mechanism == 'NOSASL':
        return TBufferedTransport(socket)

    if auth_mechanism in ['LDAP', 'PLAIN']:
        if user is None:
            user = getpass.getuser()
        if password is None:
            if auth_mechanism == 'LDAP':
                password = ''
            else:
                password = 'password'
        auth_mechanism = 'PLAIN'  
    from thrift_sasl import TSaslClientTransport
    from quark.sasl_compat import PureSASLClient

    def sasl_factory():
        return PureSASLClient(host, username=user, password=password,
                              service=kerberos_service_name)

    return TSaslClientTransport(sasl_factory, auth_mechanism, socket)
