from __future__ import absolute_import

import base64
import sys
import warnings
import logging
import string
import random
import six
import datetime
import os.path
from six.moves import http_cookies


try:
    from logging import NullHandler
except ImportError:
    # py 2.6 compat
    class NullHandler(logging.Handler):
        def emit(self, record):
            pass


def get_logger_and_init_null(logger_name):
    logger = logging.getLogger(logger_name)
    logger.addHandler(NullHandler())
    return logger


log = get_logger_and_init_null(__name__)


def as_pandas(cursor, coerce_float=False):
    """Return a pandas `DataFrame` out of an impyla cursor.

    This will pull the entire result set into memory.  For richer pandas-like
    functionality on distributed data sets, see the Ibis project.

    Parameters
    ----------
    cursor : `HiveServer2Cursor`
        The cursor object that has a result set waiting to be fetched.
        
    coerce_float : bool, optional
        Attempt to convert values of non-string, non-numeric objects to floating 
        point.

    Returns
    -------
    DataFrame
    """
    from pandas import DataFrame  # pylint: disable=import-error
    names = [metadata[0] for metadata in cursor.description]
    return DataFrame.from_records(cursor.fetchall(), columns=names, 
                                  coerce_float=coerce_float)


def _escape(s):
    e = s
    e = e.replace('\\', '\\\\')
    e = e.replace('\n', '\\n')
    e = e.replace('\r', '\\r')
    e = e.replace("'", "\\'")
    e = e.replace('"', '\\"')
    log.debug('%s => %s', s, e)
    return e


def _py_to_sql_string(value):
    if value is None:
        return 'NULL'
    elif isinstance(value, six.string_types):
        return "'" + _escape(value) + "'"
    else:
        return str(value)


# Logging-related utils

