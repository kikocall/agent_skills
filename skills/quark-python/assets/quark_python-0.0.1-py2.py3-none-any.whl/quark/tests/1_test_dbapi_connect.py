from quark.dbapi import connect

# Kerberos, require kinit
# conn = connect(
#     host='vqa711',
#     port=10000,
#     auth_mechanism='GSSAPI',
#     kerberos_service_name='hive')

# LDAP
# conn = connect(
#     host='172.18.126.72',
#     port=10000,
#     auth_mechanism = "LDAP",
#     user = "admin",
#     password = "1qaz@WSX")

# SSL
# conn = connect(
#     host='localhost',
#     port=10000,
#     use_ssl=True,
#     ca_cert="/home/xinyu.lin@transwarp.io/Project/quark-connector-python/certs/CA.pem"
# )

# PLAIN
conn = connect(
    host='172.18.148.30',
    port=10000)


cursor = conn.cursor()

cursor.execute("drop table if exists test_py_conn")
cursor.execute("CREATE TABLE test_py_conn (\n" +
        "col_tinyint TINYINT,\n" +
        "col_smallint SMALLINT,\n" +
        "col_int int,\n" +
        "col_bigint BIGINT,\n" +
        "col_float float,\n" +
        "col_double DOUBLE ,\n" +
        "col_decimal decimal(38,2),\n" +
        "col_boolean boolean,\n" +
        "col_string string,\n" +
        "col_char char(6),\n" +
        "col_varchar varchar(12),\n" +
        "col_varchar2 varchar2(24),\n" +
        "col_date date,\n" +
        "col_timestamp TIMESTAMP,\n" +
        "co15 BINARY\n" +
        # "co16 array<int>,\n" +
        # "co17 map<int,string>,\n" +
        # "co18 struct<a:int,b:double,c:string>\n" +
        ")clustered by (col_tinyint) into 2 buckets\n" +
        "stored as orc tblproperties('transactional'='true');")

cursor.execute("insert into test_py_conn values ("
               "1, "
               "2, "
               "3, "
               "4, "
               "5.55, "
               "6.66, "
               "7.77, "
               "true, "
               "'foo', "
               "'bar', "
               "'cap', "
               "'deldel', "
               "'2025-02-02', "
               "'2025-02-02 17:17:17.123', "
               "cast('hello' as binary)"
               # "array(1,2,3), "
               # "map(1,'one',2,'two'), "
               # "named_struct('a',1,'b',2.0,'c','hello')"
               ")")

cursor.execute("select * from  test_py_conn")

# 测试不同方式fetch：fetchone, fetchall
# res = cursor.fetchone()
# print(res)

# fetchall
res = cursor.fetchall()
print(res)
print(cursor.description)

# for row in cursor:
#     print(row)
print(cursor.rowcount)
cursor.execute("drop table if exists test_py_conn")

cursor.close()
conn.close()