from __future__ import absolute_import

import random
import string

from pytest import fixture, skip

from quark.dbapi import connect

from quark.tests.util import QuarkTestEnv

def _random_id(prefix='', length=8):
    return prefix + ''.join(random.sample(string.ascii_uppercase, length))

ENV = QuarkTestEnv()

@fixture(scope='session')
def host():
    return ENV.host

@fixture(scope='session')
def port():
    return ENV.port

@fixture(scope='session')
def auth_mech():
    return ENV.auth_mech

@fixture(scope='session')
def user():
    return ENV.user

@fixture(scope='session')
def password():
    return ENV.password


@fixture(scope='session')
def tmp_db():
    return _random_id('tmp_quark_')


@fixture(scope='session')
def con(host, port, auth_mech, user, password, tmp_db):
    # create the temporary database
    con = connect(host=host, port=port, auth_mechanism=auth_mech,
                  user=user, password=password)
    cur = con.cursor()
    cur.execute('CREATE DATABASE {0}'.format(tmp_db))
    cur.close()
    con.close()

    # create the actual fixture
    con = connect(host=host, port=port, auth_mechanism=auth_mech,
                  database=tmp_db, user=user, password=password)
    yield con
    con.close()

    # cleanup the temporary database
    con = connect(host=host, port=port, auth_mechanism=auth_mech,
                  user=user, password=password)
    cur = con.cursor()
    cur.execute('USE default')
    cur.execute('DROP DATABASE IF EXISTS {0} CASCADE'.format(tmp_db))

    cur.close()
    con.close()

@fixture(scope='session')
def cur(con):
    cur = con.cursor()
    yield cur
    cur.close()
