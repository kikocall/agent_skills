from __future__ import absolute_import

from sqlalchemy.engine import create_engine
from sqlalchemy import Table, Column, select, insert, text, inspect
from sqlalchemy.schema import MetaData, CreateTable

from quark.sqlalchemy import STRING, INT, DOUBLE, TINYINT, DATE, VARCHAR
from quark.tests.util import QuarkTestEnv
import pandas as pd

TEST_ENV = QuarkTestEnv()


def create_partitioned_test_table():
    metadata = MetaData()
    # TODO: add other types to this table (e.g., functional.all_types)
    return Table("mytable",
                    metadata,
                    Column('col1', STRING),
                    Column('col2', TINYINT),
                    Column('col3', INT),
                    Column('col4', DOUBLE),
                    Column('col5', DATE),
                    Column('col6', VARCHAR(10)),
                    quark_partitioned_by='(part_col STRING)',
                    quark_clustered_by='col1',
                    quark_buckets='2',
                    quark_stored_as='orc',
                    quark_table_properties={
                        'transactional': 'true'
                    })

def create_simple_test_table():
  metadata = MetaData()
  return Table("mytable",
               metadata,
               Column('col1', STRING),
               Column('col2', TINYINT),
               Column('col3', INT),
               Column('col4', DOUBLE),
               quark_stored_as='orc',
               quark_clustered_by=['col1'],
               quark_buckets='2',
               quark_table_properties={
                   'transactional': 'true'
               })

def create_test_engine(diealect):
    host = "[%s]" % TEST_ENV.host if ":" in TEST_ENV.host else TEST_ENV.host
    return create_engine('{0}://{1}:{2}'.format(diealect, host, TEST_ENV.port))

def test_sqlalchemy_quark_compilation():
    engine = create_test_engine("quark")
    observed = CreateTable(create_partitioned_test_table()).compile(engine)
    # The DATE column type of 'col5' will be replaced with TIMESTAMP.
    expected = (('\n'
                 'CREATE TABLE mytable (\n'
                 '\tcol1 STRING, \n'
                 '\tcol2 TINYINT, \n'
                 '\tcol3 INT, \n'
                 '\tcol4 DOUBLE, \n'
                 '\tcol5 TIMESTAMP, \n'
                 '\tcol6 VARCHAR(10)\n'
                 ')\n'
                 'PARTITIONED BY (part_col STRING)\n'
                 'CLUSTERED BY (col1) INTO 2 BUCKETS\n'
                 'STORED AS orc\n'
                 "TBLPROPERTIES ('transactional' = 'true')\n"
                 '\n'))
    assert expected == str(observed)

def test_sqlalchemy_multiinsert():
    engine = create_test_engine("quark")
    table = create_simple_test_table()
    # TODO: Creating a non partitioned table as I am not sure about how to insert to
    #       a partitioned table in SQL alchemy
    create_table_stmt = CreateTable(table)

    data = [
        {"col1": "a", "col2": 1, "col3": 1, "col4": 1.0},
        {"col1": "b", "col2": 2, "col3": 3, "col4": 2.0}
    ]
    insert_stmt = insert(table).values(data).compile(engine)
    expected_insert = 'INSERT INTO mytable (col1, col2, col3, col4) VALUES '\
        '(%(col1_m0)s, %(col2_m0)s, %(col3_m0)s, %(col4_m0)s), '\
        '(%(col1_m1)s, %(col2_m1)s, %(col3_m1)s, %(col4_m1)s)'
    assert expected_insert == str(insert_stmt)

    with engine.connect() as conn:
        conn.execute(create_table_stmt)
        try:
            conn.execute(insert_stmt)
            result = conn.execute(select(table.c).order_by(table.c.col1)).fetchall()
            expected_result = [('a', 1, 1, 1.0), ('b', 2, 3, 2.0)]
            assert expected_result == result
        finally:
            table.drop(conn)

def test_pandas_dataframe_to_sql():
    engine = create_test_engine("quark")

    metadata = MetaData()
    Table(
        "mytable", metadata,
        Column("a", INT),
        Column("b", INT),
        Column("c", INT),
        quark_stored_as='orc',
        quark_clustered_by=['a'],
        quark_buckets='2',
        quark_table_properties={
            'transactional': 'true'
        }
    )
    metadata.create_all(engine)

    # Creating a sample dataframe to push to the DB.
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], columns=['a', 'b', 'c'], )
    with engine.connect() as conn:
        try:
            df.to_sql('mytable', conn, if_exists='append', index=False)
            table = pd.read_sql('DESCRIBE mytable', conn)
            columns = table['col_name'].tolist()
            assert ['a', 'b', 'c'] == columns
        finally:
            conn.execute(text('DROP TABLE mytable'))

def test_showdatabases():
    engine = create_test_engine("quark")
    # create database and table, finally drop all
    with engine.connect() as conn:
        try:
            insp = inspect(engine)
            result = insp.get_schema_names()
            # print(result)
        finally:
            conn.close()
