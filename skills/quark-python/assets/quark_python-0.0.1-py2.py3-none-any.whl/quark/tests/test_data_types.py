import datetime
import pytest
import sys
from pytest import fixture
from decimal import Decimal

stored = 'stored as holodesk'

@fixture(scope='function')
def decimal_table(cur):
    table_name = 'tmp_decimal_table'
    ddl = """CREATE TABLE {0} (
                 f1 decimal(10, 2),
                 f2 decimal(7, 5),
                 f3 decimal(38, 17)) {1}""".format(table_name, stored)
    cur.execute(ddl)
    try:
        yield table_name
    finally:
        cur.execute("DROP TABLE {0}".format(table_name))


@pytest.mark.connect
def test_cursor_description_precision_scale(cur, decimal_table):
    # According to the DBAPI 2.0, these are the 7 fields of cursor.description
    # - name
    # - type_code
    # - display_size
    # - internal_size
    # - precision
    # - scale
    # - null_ok
    expected = [(10, 2),
                (7, 5),
                (38, 17)]
    cur.execute('select * from {0} limit 0'.format(decimal_table))
    observed = [(t[4], t[5]) for t in cur.description]
    for (exp, obs) in zip(expected, observed):
        assert exp == obs


@fixture(scope='function')
def decimal_table2(cur):
    table_name = 'tmp_decimal_table2'
    ddl = """CREATE TABLE {0} (val decimal(18, 9)) {1}""".format(table_name, stored)
    cur.execute(ddl)
    cur.execute('''insert into {0}
                   values (cast(123456789.123456789 as decimal(18, 9))),
                          (cast(-123456789.123456789 as decimal(18, 9))),
                          (cast(0.000000001 as decimal(18, 9))),
                          (cast(-0.000000001 as decimal(18, 9))),
                          (cast(999999999.999999999 as decimal(18, 9))),
                          (cast(-999999999.999999999 as decimal(18, 9))),
                          (NULL)'''.format(table_name))
    try:
        yield table_name
    finally:
        cur.execute("DROP TABLE {0}".format(table_name))


def common_test_decimal(cur, decimal_table):
    """Read back a few decimal values in a wide range."""
    cur.execute('select val from {0} order by val'.format(decimal_table))
    results = cur.fetchall()
    assert results == [(None,),
                       (Decimal('-999999999.999999999'),),
                       (Decimal('-123456789.123456789'),),
                       (Decimal('-0.000000001'),),
                       (Decimal('0.000000001'),),
                       (Decimal('123456789.123456789'),),
                       (Decimal('999999999.999999999'),)]


@pytest.mark.connect
def test_decimal_basic(cur, decimal_table2):
    common_test_decimal(cur, decimal_table2)


# @pytest.mark.connect
# def test_decimal_no_string_conv(cur_no_string_conv, decimal_table2):
#     common_test_decimal(cur_no_string_conv, decimal_table2)


@fixture(scope='function')
def date_table(cur):
    table_name = 'tmp_date_table'
    ddl = """CREATE TABLE {0} (d date) {1}""".format(table_name, stored)
    cur.execute(ddl)
    cur.execute('''insert into {0}
                   values (date "0001-01-01"), (date "1999-9-9")'''.format(table_name))
    try:
        yield table_name
    finally:
        cur.execute("DROP TABLE {0}".format(table_name))


def common_test_date(cur, date_table):
    """Read back a couple of data values in a wide range."""
    cur.execute('select d from {0} order by d'.format(date_table))
    results = cur.fetchall()
    assert results == [(datetime.date(1, 1, 1),), (datetime.date(1999, 9, 9),)]


@pytest.mark.connect
def test_date_basic(cur, date_table):
    common_test_date(cur, date_table)


# @pytest.mark.connect
# def test_date_no_string_conv(cur_no_string_conv, date_table):
#     common_test_date(cur_no_string_conv, date_table)


@fixture(scope='function')
def timestamp_table(cur):
    table_name = 'tmp_timestamp_table'
    ddl = """CREATE TABLE {0} (ts timestamp) {1}""".format(table_name, stored)
    cur.execute(ddl)
    cur.execute('''insert into {0}
                   values (cast("1400-01-01 00:00:00" as timestamp)),
                          (cast("2014-06-23 13:30:51" as timestamp)),
                          (cast("2014-06-23 13:30:51.123" as timestamp)),
                          (cast("2014-06-23 13:30:51.123456" as timestamp)),
                          (cast("9999-12-31 23:59:59" as timestamp))'''.format(table_name))
    try:
        yield table_name
    finally:
        cur.execute("DROP TABLE {0}".format(table_name))


def common_test_timestamp(cur, timestamp_table):
    """Read back a few timestamp values in a wide range."""
    cur.execute('select ts from {0} order by ts'.format(timestamp_table))
    results = cur.fetchall()
    assert results == [(datetime.datetime(1400, 1, 1, 0, 0),),
                       (datetime.datetime(2014, 6, 23, 13, 30, 51),),
                       (datetime.datetime(2014, 6, 23, 13, 30, 51, 123000),),
                       (datetime.datetime(2014, 6, 23, 13, 30, 51, 123000),),
                       (datetime.datetime(9999, 12, 31, 23, 59, 59),)]


@pytest.mark.connect
def test_timestamp_basic(cur, timestamp_table):
    common_test_timestamp(cur, timestamp_table)


# @pytest.mark.connect
# def test_timestamp_no_string_conv(cur_no_string_conv, timestamp_table):
#     common_test_timestamp(cur_no_string_conv, timestamp_table)


@pytest.mark.connect
def test_utf8_strings(cur):
    """Use STRING/VARCHAR/CHAR values  with multi byte unicode code points in a query."""
    cur.execute('select "引擎", cast("引擎" as varchar(6)), cast("引擎" as char(6))')
    result = cur.fetchone()
    assert result == ("引擎", "引擎", "引擎    ")

    cur.execute('select unhex("AA")')
    result = cur.fetchone()[0]
    assert result == b"\xaa"
    assert result.decode("UTF-8", "replace") == u"�"


@pytest.mark.connect
def test_string_conv(cur):
    cur.execute('select "Test string"')
    result = cur.fetchone()
    is_unicode = isinstance(result[0], str)


@pytest.mark.connect
def test_string_no_string_conv(cur):
    cur.execute('select "Test string"')
    result = cur.fetchone()
    assert isinstance(result[0], str)