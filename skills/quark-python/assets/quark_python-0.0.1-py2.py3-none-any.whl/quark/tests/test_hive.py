from quark.tests.util import QuarkTestEnv

ENV = QuarkTestEnv()
def test_hive_queries(cur):
    cur.execute('DROP TABLE if exists torc1')
    cur.execute('CREATE TABLE torc1 (a STRING, b INT, c DOUBLE) '
                'clustered by (a) into 2 buckets '
                'stored as orc tblproperties(\'transactional\'=\'true\');')

    cur.execute('SHOW TABLES')
    tables = cur.fetchall()
    assert any([t[0] == 'torc1' for t in tables])

    cur.execute("INSERT INTO torc1 "
                "VALUES ('foo', 1, 0.5), ('bar', 2, NULL), ('baz', 3, 6.2)")

    cur.execute('SELECT b FROM torc1 LIMIT 2')
    assert len(cur.description) == 1
    assert cur.description[0][0] == 'b'
    results = cur.fetchall()
    assert len(results) == 2

    cur.execute('SELECT * FROM torc1 WHERE c IS NOT NULL')
    results = cur.fetchall()
    assert len(results) == 2

    cur.execute("SELECT c from torc1 WHERE a = 'foo'")
    results = cur.fetchall()
    assert len(results) == 1
    assert results[0][0] == 0.5

    cur.execute("SELECT c from torc1 WHERE a = 'bar'")
    results = cur.fetchall()
    assert len(results) == 1
    assert results[0][0] is None

    cur.executemany("INSERT INTO torc1 VALUES (?, ?, ?)",
                    [['a', 4, 1.0], ['%s', 5, None]],
                    {'paramstyle': 'qmark'})

    cur.execute("SELECT * from torc1 WHERE b = 4")
    results = cur.fetchmany(1)
    assert results == [('a', 4, 1.0)]

    cur.execute("SELECT * from torc1 WHERE b = 4")
    results = cur.fetchall()
    assert results == [('a', 4, 1.0)]

    cur.execute("SELECT * from torc1 WHERE b = 5")
    results = cur.fetchall()
    assert results == [('%s', 5, None)]

    cur.execute('DROP TABLE torc1')

    cur.execute('SHOW TABLES')
    tables = cur.fetchall()
    assert all([t[0] != 'torc1' for t in tables])
