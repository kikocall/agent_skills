import os
import sys
import six

identity = lambda x: x

def get_env_var(name, coercer, default):
    if name in os.environ:
        return coercer(os.environ[name])
    else:
        sys.stderr.write("{0} not set; using {1!r}\n".format(name, default))
        return default
class QuarkTestEnv(object):

    def __init__(self, host=None, port=None, auth_mech=None):
        if host is not None:
            self.host = host
        else:
            self.host = get_env_var('TEST_HOST', identity, '172.18.148.30')

        if port is not None:
            self.port = port
        else:
            self.port = get_env_var('TEST_PORT', int, 10000)

        self.user = get_env_var('TEST_USER', identity,
                                     'hive')

        self.password = get_env_var('TEST_PASSWORD', identity,
                                'password')

        if auth_mech is not None:
            self.auth_mech = auth_mech
        else:
            self.auth_mech = get_env_var('TEST_AUTH', identity,
                                         'PLAIN')

        self.ssl_cert = get_env_var('SSL_CERT', identity, "")

    def __repr__(self):
        kvs = ['{0}={1}'.format(k, v)
               for (k, v) in six.iteritems(self.__dict__)]
        return 'QuarkTestEnv(\n    {0})'.format(',\n    '.join(kvs))